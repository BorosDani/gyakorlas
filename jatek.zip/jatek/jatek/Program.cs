﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jatek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            menu();
        }

        private static void menu() 
        {
            while (true)
            {
                Console.WriteLine("\tÜdvözöllek egy rövid rpg játékban!\n");
                Console.WriteLine("\t------------------------------");
                Console.WriteLine("\t|{0, 10} - {1, 5} {2, 7}", "1.", "Új játék", "|");
                Console.WriteLine("\t|{0, 10} - {1, 5} {2, 7}", "2.", "Betöltés", "|");
                Console.WriteLine("\t|{0, 10} - {1, 5} {2, 8}", "3.", "Kilépés", "|");
                Console.WriteLine("\t------------------------------\n");
                Console.Write("\t#");

                string valasztas = Console.ReadLine();

                if (valasztas == "1")
                {
                    Console.Clear();
                    ujjatek();
                    Console.Clear();
                }
                else if (valasztas == "2")
                {
                    Console.Clear();
                    betoltes();
                }

                else if (valasztas == "3")
                {
                    Environment.Exit(0);
                }

                else
                {
                    Console.WriteLine("Nem jó adat!");
                }
            }
        }

        private static void ujjatek() 
        {
            Console.WriteLine("\t--- Karakter készítés ---\n\n");
            Console.Write("\tKarakter neve: ");
            string KarakterNev = Console.ReadLine();
            cast();

            string KarakterFajl = @"D:\Saját mappák\Dani\Programozás\C#_programok\sajat\" + KarakterNev + ".txt";
            StreamWriter irocsatorna = new StreamWriter(KarakterFajl, false, Encoding.GetEncoding("iso-8859-2"));

            irocsatorna.WriteLine(KarakterNev);

            irocsatorna.Close();
            Console.ReadLine();
        }

        private static void cast() 
        {
            Console.WriteLine(" -----------------------------------------------------------------");
            Console.WriteLine("|{0, 20} | {1, 20} {2, 22}", "Faj", "Tulajdonságok", "|");
            Console.WriteLine(" -----------------------------------------------------------------");
            Console.WriteLine("|{0, 20} | {1, 20} {2, 22}", "Ember", "Tanulékony", "|");
            Console.WriteLine("|{0, 20} | {1, 20} {2, 22}", "Ork", "Erős", "|");
            Console.WriteLine("|{0, 20} | {1, 20} {2, 22}", "Elf", "Gyors", "|");
            Console.WriteLine(" -----------------------------------------------------------------");
            Console.WriteLine("\n\nAz ember mint faj elterjett ebben a világban, az életereje 100 kezdésnél, pénzben nem szűkölködik 500 arannyal kezd, egy karddal az oldalán és egy pajzs mely megvédi (2 sebzés, 3 védelem, fürgeség 2).");
            Console.WriteLine("\n\nAz orkok nem túl közkedveltek, de ezen változtathatsz, az életereje 120 kezdésnél, pénzben szűkölködik 50 arannyal kezd, két baltával a kezében változtathat az orkok sorsán (3 sebzés, 2 védelem, fürgeség 1).");
            Console.WriteLine("\n\nAz elfek beforduló lények néha a létezésük is kérdéses, de ők nem igazán hisznek a harcban viszont kitartóak és meggyőzők, az életereje 130 kezdésnél, 200 arannyal kezd, egy ijjal és egy tőrrel (2 sebzés, 1 védelem, fürgeség 4).");
        }

        private static void betoltes()
        {
            Console.WriteLine("Még nincs kész!");
        }
    }
}
