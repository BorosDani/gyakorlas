﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jatek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            menu();
        }

        private static void menu()
        {
            while (true)
            {
                Console.WriteLine("\tÜdvözöllek egy rövid rpg játékban!\n");
                Console.WriteLine("\t------------------------------");
                Console.WriteLine("\t|{0, 10} - {1, 5} {2, 7}", "1.", "Új játék", "|");
                Console.WriteLine("\t|{0, 10} - {1, 5} {2, 7}", "2.", "Betöltés", "|");
                Console.WriteLine("\t|{0, 10} - {1, 5} {2, 8}", "3.", "Kilépés", "|");
                Console.WriteLine("\t------------------------------\n");
                Console.Write("\t#");

                string valasztas = Console.ReadLine();

                if (valasztas == "1")
                {
                    Console.Clear();
                    ujjatek();
                    Console.Clear();
                }
                else if (valasztas == "2")
                {
                    Console.Clear();
                    betoltes();
                }

                else if (valasztas == "3")
                {
                    Environment.Exit(0);
                }

                else
                {
                    Console.Clear();
                    Console.WriteLine("Nem megfelelő adat!");
                }
            }
        }

        private static void ujjatek()
        {
            karakter();
        }

        private static void karakter()
        {
            Console.WriteLine("--- Karakter készítés ---\n\n");
            Console.Write("Írd be a hősöd nevét: ");
            string karakternev = Console.ReadLine();

            //Cast alapú információk
            bool faj = false;
            string Valasztott_faj;
            int HP = 0;
            int arany = 0;
            int ero = 0;
            int mozgas = 0;
            string felszereles;
            int bonusz = 0;
            //------------------------------------------------

            cast_leiras();
            Console.Write("\n\n\n\nVálassz fajt: ");

            string karakterfajl = @"" + karakternev + ".txt";
            StreamWriter irocsatorna = new StreamWriter(karakterfajl, false, Encoding.GetEncoding("iso-8859-2"));

            irocsatorna.WriteLine(karakternev);
            while (faj == false) 
            {
                Valasztott_faj = Console.ReadLine();

                if (Valasztott_faj == "1")
                {
                    faj = true;
                    Valasztott_faj = "Ember";
                    HP = 120;
                    arany = 500;
                    ero = 2;
                    mozgas = 2;
                    felszereles = "Kard + Pajzs";
                    bonusz = 2;
                    irocsatorna.WriteLine(Valasztott_faj);
                    irocsatorna.WriteLine(HP);
                    irocsatorna.WriteLine(arany);
                    irocsatorna.WriteLine(ero);
                    irocsatorna.WriteLine(mozgas);
                    irocsatorna.WriteLine(felszereles);
                    irocsatorna.WriteLine(bonusz);
                }

                else if (Valasztott_faj == "2")
                {
                    faj = true;
                    Valasztott_faj = "Ork";
                    HP = 150;
                    arany = 50;
                    ero = 4;
                    mozgas = 1;
                    felszereles = "Kétkezes bárd";
                    bonusz = 2;
                    irocsatorna.WriteLine(Valasztott_faj);
                    irocsatorna.WriteLine(HP);
                    irocsatorna.WriteLine(arany);
                    irocsatorna.WriteLine(ero);
                    irocsatorna.WriteLine(mozgas);
                    irocsatorna.WriteLine(felszereles);
                    irocsatorna.WriteLine(bonusz);
                }

                else if (Valasztott_faj == "3")
                {
                    faj = true;
                    Valasztott_faj = "Elf";
                    HP = 100;
                    arany = 200;
                    ero = 1;
                    mozgas = 4;
                    felszereles = "Tőr";
                    bonusz = 2;
                    irocsatorna.WriteLine(Valasztott_faj);
                    irocsatorna.WriteLine(HP);
                    irocsatorna.WriteLine(arany);
                    irocsatorna.WriteLine(ero);
                    irocsatorna.WriteLine(mozgas);
                    irocsatorna.WriteLine(felszereles);
                    irocsatorna.WriteLine(bonusz);
                }

                else 
                {
                    Console.WriteLine("Nem megfelelő adat!");
                }
            }

            irocsatorna.Close();
        }

        private static void cast_leiras() 
        {
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("\t Castokról információ");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("\n\n\t--- Ember ---\n Ezt a világot az emberek lakják nagyrészt, ez álltal könnyebb kezdetekre tehetsz szert.\n Az ember általában nagyon gyorsan tanul a hibáiból ez észrevehető a harcoknál, több tapasztalatra tehetnek szert mint a többiek.\n Előnyt is érezhet az ember ugyanis megakarják tartani maguknak a világot azzal, hogy összefognak és kitaszítják a másokat.\n\n Általános jellemzők: \n\n\tÉleterő: 120HP\n\tArany: 500\n\tErő: 2 sebzés\n\tMozgás: 2 gyorsaság\n\tFelszerelés: Kard + pajzs\n\tBónusz: 2x tapasztalat");
            Console.WriteLine("\n\n\n\t--- Ork ---\n Az orkok nem éppen a nyugodt természetükről híresek, ezért sem kedvelik annyira őket az emberek se az elfek.\n Az orkok nem az eszüket, gyorsaságukat vagy tapasztalataikat használják ki, hanem a nyers erejüket ami gyakran segíti meg őket szorult időkben.\n Kihalofélben vannak, de ezen változtatni akarnak ezért is folyik sok harc a terület miatt.\n\n Általános jellemzők: \n\n\tÉleterő: 150HP\n\tArany: 50\n\tErő: 4 sebzés\n\tMozgás: 1 gyorsaság\n\tFelszerelés: Kétkezes Bárd\n\tBónusz: felére gyengíti az ellenfél pajzsát");
            Console.WriteLine("\n\n\n\t--- Elf ---\n Az elfek szöges ellentétei az orkoknak a legnyugodtabb lények ezen a világon ugyanakkor nem félnek bepiszkolni a kezüket földjeik megvédése érdekében.\n Ezek a manók a gyorsaságukat és tudásukat használják a csatatéren, de próbálják a harcot kerülni.\n Nem tűntek el a világszínéről csak bújkálnak a magas lombú erdeikben kerülve a vérontást.\n\n Általános jellemzők: \n\n\tÉleterő: 100HP\n\tArany: 200\n\tErő: 1 sebzés\n\tMozgás: 4 gyorsaság\n\tFelszerelés: Tőr\n\tBónusz: Nagy esélyel mellé ütnek az ellenfelek gyorsaságuk miatt");
        }

        private static void betoltes()
        {
            Console.WriteLine("Nincs kész!"); // Itt elakadtál, nem tudod hogyan csináld (static változokkal vagy azoknélkül) -------> Adatok tárolására a  betöltéshez
        }
    }
}
