﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JanosVitez_II
{
    class Program
    {
        static void Main(string[] args)
        {
            janosvitez();
            Console.ReadLine();

            /*      
             *      a.      Kérj be egy betűt, és mondd meg, hányszor szerepel a dokumentumban. Figyelj arra, hogy vannak betűk, melyek egy szóban többször is előfordulhatnak.

                    b.      A bekért betűről mondd meg, hányadik szóban szerepel először, és írasd ki ezt a szót.

                    c.       Írasd ki a képernyőre a verset, úgy mintha hátulról olvasnánk visszafelé (csak a szavak sorrendjét változtasd meg).

                    d.      Írasd ki a verset ritkítva (minden betű között legyen egy szóköz).

                    e.      Írd a verset 2x fájlba úgy, hogy függőlegesen, fentről lefelé kelljen olvasni. Először minden sorba egyetlen szó kerüljön, utána pedig minden sorba egyetlen betű kerüljön. Elé legyen beírva: „szavanként:”, „betűnként:”. A fájl neve: JanosVitezFuggoleges.txt, helye a Forras mappa, mely egy szinten legyen a projektmappával.
            */
        }

        private static void janosvitez() 
        {
            Console.WriteLine("--- János Vitéz feladatok 2.rész ---\n\n");
            Console.Write("A szövegben melyik betűt szeretnéd megszámolni? ");
            //char betu = Convert.ToChar(Console.ReadLine());
            string betu = Console.ReadLine();
            int betu_szama = 0;

            string szoveg;
            string [] szavak;
            StreamReader olvasocsatrona = new StreamReader("JanosVitez.txt");
            while (!olvasocsatrona.EndOfStream) 
            {
                szoveg = olvasocsatrona.ReadLine();
                szavak = szoveg.Split(' ');
            }
            olvasocsatrona.Close();

            Console.WriteLine($"A(z) összes ({betu}): {betu_szama}");
        }
    }
}
