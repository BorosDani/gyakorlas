<?php
session_start();

// Ha nincs bejelentkezve, irány a login
if (!isset($_SESSION['logged']) || !$_SESSION['logged']) {
    header('Location: login.php');
    exit();
}

// Kosár inicializálás
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Ha a "Add to Cart" gomb meg lett nyomva
if (isset($_POST['add_to_cart'])) {
    $product = $_POST['add_to_cart'];
    $_SESSION['cart'][] = $product;
    header('Location: index.php'); // újratöltés a post duplikálás elkerülésére
    exit();
}

// CSS fájl beállítása cookie-ból (ha van)
$selectedStyle = isset($_COOKIE['selected_style']) ? $_COOKIE['selected_style'] : 'indexstyle.css';
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kezdőlap</title>
    <!-- CSS betöltése a cookie alapján -->
    <link id="stylesheet" rel="stylesheet" href="<?php echo $selectedStyle; ?>">

    <script>
        // Funkció a cookie-ba íráshoz
        function setCookie(cname, cvalue, exdays) {
            var d = new Date();
            d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
        }

        // Funkció a CSS stílus váltásához
        function changeCSS() {
            var styleSheet = document.getElementById("stylesheet");
            var selectedStyle = document.getElementById("css-switcher").value;

            // Frissítjük a cookie-t a kiválasztott stílussal
            setCookie("selected_style", selectedStyle, 30);
            
            // A CSS fájl lecserélése
            styleSheet.setAttribute("href", selectedStyle);
        }
    </script>
</head>
<body>

    <div class="menu">
        <form action="logout.php" method="post">
            <input type="button" class="buttons" value="Home page" onclick="location.href='index.php'">
            <input type="button" class="buttons" value="About us" onclick="location.href='about.php'">
            <input type="button" class="buttons" value="Cart" onclick="location.href='cart.php'">
            <input type="submit" class="logout_button" value="Logout">
        </form>
        
        <!-- CSS váltó -->
        <select id="css-switcher" onchange="changeCSS()">
            <option value="indexstyle.css" <?php echo ($selectedStyle == 'indexstyle.css') ? 'selected' : ''; ?>>Default Style</option>
            <option value="indexstyle2.css" <?php echo ($selectedStyle == 'indexstyle2.css') ? 'selected' : ''; ?>>Dynamic Style</option>
            <option value="indexstyle3.css" <?php echo ($selectedStyle == 'indexstyle3.css') ? 'selected' : ''; ?>>Colorful Style</option>
        </select>
    </div>

    <div class="name">
        <h1>Welcome <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    </div>

    <div class="main">
        <h1>Our Available Games</h1>
        <div class="product-list">
            <!-- Dead Space -->
            <div class="product-card">
                <img src="https://cdn.cloudflare.steamstatic.com/steam/apps/1693980/header.jpg" alt="Dead Space Remake" style="height: 100px;">
                <h3>Dead Space</h3>
                <p>Price: 39.99$</p>
                <form method="post">
                    <button type="submit" name="add_to_cart" value="Dead Space" class="shop-button">Add to Cart</button>
                </form>
            </div>

            <!-- Witcher 3 -->
            <div class="product-card">
                <img src="https://upload.wikimedia.org/wikipedia/en/0/0c/Witcher_3_cover_art.jpg" alt="Witcher 3" style="height: 300px;">
                <h3>The Witcher 3</h3>
                <p>Price: 29.99$</p>
                <form method="post">
                    <button type="submit" name="add_to_cart" value="The Witcher 3" class="shop-button">Add to Cart</button>
                </form>
            </div>

            <!-- Fallout 4 -->
            <div class="product-card">
                <img src="https://cdn.cloudflare.steamstatic.com/steam/apps/377160/header.jpg" alt="Fallout 4" style="height: 100px;">
                <h3>Fallout 4</h3>
                <p>Price: 19.99$</p>
                <form method="post">
                    <button type="submit" name="add_to_cart" value="Fallout 4" class="shop-button">Add to Cart</button>
                </form>
            </div>
        </div>
    </div>

    <footer>
        &copy; 2025 GameShop. All rights reserved.
    </footer>

</body>
</html>
