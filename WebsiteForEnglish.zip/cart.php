<?php
session_start();

// Ha nincs bejelentkezve, irány a login
if (!isset($_SESSION['logged']) || !$_SESSION['logged']) {
    header('Location: login.php');
    exit();
}

// Kosár inicializálás, ha még nincs
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Ha a "Remove" gomb meg lett nyomva
if (isset($_POST['remove_from_cart'])) {
    $productToRemove = $_POST['remove_from_cart'];
    // Termék eltávolítása a kosárból
    if (($key = array_search($productToRemove, $_SESSION['cart'])) !== false) {
        unset($_SESSION['cart'][$key]);
        $_SESSION['cart'] = array_values($_SESSION['cart']); // újraszámoljuk az indexeket
    }
}

// CSS fájl beállítása cookie-ból (ha van)
$selectedStyle = isset($_COOKIE['selected_style']) ? $_COOKIE['selected_style'] : 'indexstyle.css';
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kosár</title>
    <!-- CSS betöltése a cookie alapján -->
    <link id="stylesheet" rel="stylesheet" href="<?php echo $selectedStyle; ?>">

    <script>
        // Funkció a cookie-ba íráshoz
        function setCookie(cname, cvalue, exdays) {
            var d = new Date();
            d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
        }

        // Funkció a CSS stílus váltásához
        function changeCSS() {
            var styleSheet = document.getElementById("stylesheet");
            var selectedStyle = document.getElementById("css-switcher").value;

            // Frissítjük a cookie-t a kiválasztott stílussal
            setCookie("selected_style", selectedStyle, 30);
            
            // A CSS fájl lecserélése
            styleSheet.setAttribute("href", selectedStyle);
        }
    </script>
</head>
<body>
    <div class="menu">
        <form action="logout.php" method="post">
            <input type="button" class="buttons" value="Home page" onclick="location.href='index.php'">
            <input type="button" class="buttons" value="About us" onclick="location.href='about.php'">
            <input type="button" class="buttons" value="Cart" onclick="location.href='cart.php'">
            <input type="submit" class="logout_button" value="Logout">
        </form>

        <!-- CSS váltó -->
        <select id="css-switcher" onchange="changeCSS()">
            <option value="indexstyle.css" <?php echo ($selectedStyle == 'indexstyle.css') ? 'selected' : ''; ?>>Default Style</option>
            <option value="indexstyle2.css" <?php echo ($selectedStyle == 'indexstyle2.css') ? 'selected' : ''; ?>>Dynamic Style</option>
            <option value="indexstyle3.css" <?php echo ($selectedStyle == 'indexstyle3.css') ? 'selected' : ''; ?>>Colorful Style</option>
        </select>
    </div>

    <div class="name">
        <h1>Welcome <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    </div>

    <div class="main">
        <h1>Your Cart</h1>
        <?php if (empty($_SESSION['cart'])): ?>
            <p>Your cart is empty.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($_SESSION['cart'] as $product): ?>
                    <li>
                        <?php echo htmlspecialchars($product); ?>
                        <form method="post" style="display:inline;">
                            <button type="submit" name="remove_from_cart" value="<?php echo htmlspecialchars($product); ?>" class="remove-button">Remove</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>

    <footer>
        &copy; 2025 GameShop. All rights reserved.
    </footer>

</body>
</html>
