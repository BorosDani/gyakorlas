<?php
session_start();

// Ha nincs bejelentkezve, irány a login
if (!isset($_SESSION['logged']) || !$_SESSION['logged']) {
    header('Location: login.php');
    exit();
}

// CSS fájl beállítása cookie-ból (ha van)
$selectedStyle = isset($_COOKIE['selected_style']) ? $_COOKIE['selected_style'] : 'indexstyle.css';
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <!-- CSS betöltése a cookie alapján -->
    <link id="stylesheet" rel="stylesheet" href="<?php echo $selectedStyle; ?>">

    <script>
        // Funkció a cookie-ba íráshoz
        function setCookie(cname, cvalue, exdays) {
            var d = new Date();
            d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
        }

        // Funkció a CSS stílus váltásához
        function changeCSS() {
            var styleSheet = document.getElementById("stylesheet");
            var selectedStyle = document.getElementById("css-switcher").value;

            // Frissítjük a cookie-t a kiválasztott stílussal
            setCookie("selected_style", selectedStyle, 30);
            
            // A CSS fájl lecserélése
            styleSheet.setAttribute("href", selectedStyle);
        }
    </script>
</head>
<body>

    <div class="menu">
        <form action="logout.php" method="post">
            <input type="button" class="buttons" value="Home page" onclick="location.href='index.php'">
            <input type="button" class="buttons" value="About us" onclick="location.href='about.php'">
            <input type="button" class="buttons" value="Cart" onclick="location.href='cart.php'">
            <input type="submit" class="logout_button" value="Logout">
        </form>
        
        <!-- CSS váltó -->
        <select id="css-switcher" onchange="changeCSS()">
            <option value="indexstyle.css" <?php echo ($selectedStyle == 'indexstyle.css') ? 'selected' : ''; ?>>Default Style</option>
            <option value="indexstyle2.css" <?php echo ($selectedStyle == 'indexstyle2.css') ? 'selected' : ''; ?>>Dynamic Style</option>
            <option value="indexstyle3.css" <?php echo ($selectedStyle == 'indexstyle3.css') ? 'selected' : ''; ?>>Colorful Style</option>
        </select>
    </div>

    <div class="name">
        <h1>About Us</h1>
    </div>

    <section class="about-us">
        <div class="container">
            <p>Welcome to <strong>GameCon</strong>, where every game is created with the purpose of delivering unique and unforgettable experiences to players.</p>

            <p>We believe that video games offer more than just entertainment; they provide an experience that connects people, sparks creativity, and creates challenges. Every game we make has a strong story behind it, designed to entertain and make players think, while utilizing the latest technological advancements.</p>

            <p><strong>Our founding team</strong> consists of passionate developers, designers, and storytellers who work together to create the most exciting and innovative interactive experiences. Whether it's a deep story-driven adventure, action-packed moments, or strategic challenges, each of our projects aims to provide a lasting impression.</p>

            <p>Our team is constantly evolving, embracing new technologies to ensure that each game we create is unique and special. Pushing the boundaries of the gaming industry is at the heart of every project we undertake. We love what we do, and we are committed to crafting experiences that inspire players to explore new worlds, solve complex puzzles, and build lasting connections with others.</p>

            <p><strong>We are building our future together</strong>, and we can't wait to share even more fantastic adventures and experiences with players worldwide. Join us, and let's create something truly special!</p>
        </div>
    </section>

    <footer>
        &copy; 2025 GameShop. All rights reserved.
    </footer>

</body>
</html>
