<?php
    $db = 'localhost';
    $dbuser = 'root';
    $dbpassw = '';
    $dbname = 'borosdusers'; 

    $con = mysqli_connect($db, $dbuser, $dbpassw, $dbname);

    if(mysqli_connect_errno())
    {
        exit('Failed to connect to MyDQL: '. mysqli_connect_error());
    }
?>