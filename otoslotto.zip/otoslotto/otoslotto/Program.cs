﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace otoslotto
{
    class Program
    {
        static void Main(string[] args)
        {
            otoslottofeladatok();
            Console.ReadLine();
        }

        private static void lottoszamok()
        {
            Console.WriteLine("     52. hét lottószámai\n");
            for (int i = 1; i <= 90; i++)
            {
                Console.Write(i + " ");
                if (i % 10 == 0) 
                {
                    Console.WriteLine();
                }
                if (i < 10) 
                {
                    Console.Write(" ");
                }
            }
            Console.Write("\nAdd meg tippjeidet: ");
        }

        private static void otoslottofeladatok()
        {
            //1)
            int[] tippek = new int[5];
            for (int i = 0; i <= 4; i++)
            {
                lottoszamok();
                tippek[i] = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
            }

            //2)
            int jelenlegiSzam = tippek[0];
            Console.Write("Az általad megadott számok növekvő sorrendben: ");
            for (int i = 0; i < tippek.Length; i++)
            {
                for (int j = 0; j < tippek.Length; j++)
                {
                    Console.WriteLine(tippek[j]);
                }
            }

            //3)
            /*
            List<string> nyeroszamok = new List<string>();
            string szam;

            Console.Write("\n\nÍrj be egy számot 1 és 51 között: ");
            int lottoHet = Convert.ToInt32(Console.ReadLine());

            StreamReader olvasocsatorna = new StreamReader("lottoszamok.csv", Encoding.GetEncoding("iso-8859-2"), false);
            while (olvasocsatorna.EndOfStream) 
            {
                szam = olvasocsatorna.ReadLine();
                nyeroszamok.Add(szam);
            }
            olvasocsatorna.Close();

            for (int i = 0; i < nyeroszamok.Count; i++)
            {
                for (int j = 0; j < nyeroszamok.Count; j++)
                {
                    if (i == lottoHet)
                    {
                        Console.Write(nyeroszamok[j] + " ");
                    }
                }
            }
            */
        }
    }
}
