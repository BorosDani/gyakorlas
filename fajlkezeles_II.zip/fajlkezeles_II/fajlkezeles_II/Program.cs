﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fajlkezeles_II
{
    class Program
    {
        static int a_sav, b_sav, c_sav;
        struct EpitmenyStruktura //Ez egy telek adatainak szerkezete lesz. (Nem tárolunk adatot[Építmény adatszerkezete])
        {
            //Struktúra adatszerkezet megadása.
            public string tulajAdoszam; //A telek tulajdonosának adoszáma
            public string utcaNev;      //A telek utcának a neve
            public string hazSzam;      //A telek házszáma
            public char adosav;         //A telek adósávja (besorolás pl.: A,B,C)
            public int terulet;         //Az építmény alapterülete
        }

        private static int ado(char adosav,  int alapterulet) 
        {
            int fizetendo_ado;

            if (adosav == 'A')
            {
                fizetendo_ado = a_sav * alapterulet;
            }

            else if (adosav == 'B')
            {
                fizetendo_ado = b_sav * alapterulet;
            }

            else
            {
                fizetendo_ado = c_sav * alapterulet;
            }


            if (fizetendo_ado < 10000)
            {
                fizetendo_ado = 0;
            }

            return fizetendo_ado;
        }
        static void Main(string[] args)
        {
            epitmenyado();
            Console.ReadLine();
        }

        private static void epitmenyado() 
        {
            //Deklaráció

            //Fálj beolvasása és adatok eltárolása
            StreamReader olvasocsatorna = new StreamReader("utca.txt");

            string elsosor = olvasocsatorna.ReadLine();
            string sor;

            a_sav = int.Parse(elsosor.Split(' ')[0]);
            b_sav = int.Parse(elsosor.Split(' ')[1]);
            c_sav = int.Parse(elsosor.Split(' ')[2]);

            List < EpitmenyStruktura > adatok = new List<EpitmenyStruktura>(); //Struktúra felhasználásával létrehozott lista.
            string[] darabol;

            while (!olvasocsatorna.EndOfStream) //Amíg nincs vége a fájlnak.
            {
                sor = olvasocsatorna.ReadLine();
                darabol = sor.Split(' ');

                EpitmenyStruktura epitmeny = new EpitmenyStruktura(); //Példányosítás (Adat felvétel)

                epitmeny.tulajAdoszam = darabol[0]; //Itt megkeressük az adószámot (ami a darabolból jön ki) az első elem azaz a 0
                epitmeny.utcaNev = darabol[1];
                epitmeny.hazSzam = darabol[2];
                epitmeny.adosav = char.Parse(darabol[3]);
                epitmeny.terulet = int.Parse(darabol[4]);

                adatok.Add(epitmeny);
            }

            olvasocsatorna.Close();

            Console.WriteLine("1. feladat) Utca.txt beolvasása (megtörtént)");



            //Console.WriteLine("2. feladat) A mintában {0} telek szerepel.", adatok.Count);
            // VAGY
            //2. feladat
            Console.WriteLine($"\n2. feladat) A mintában {adatok.Count} telek szerepel.");



            //3. feladat
            Console.Write($"\n3. feladat) Egy tulajdonos adószáma: ");
            string adoszam = Console.ReadLine();
            bool talalat = false;

            for (int i = 0; i < adatok.Count; i++)
            {
                if (adoszam == adatok[i].tulajAdoszam)
                {
                    Console.WriteLine($"{adatok[i].utcaNev} utca {adatok[i].hazSzam}");
                    talalat = true;
                }
            }

            if(!talalat)
            {
                Console.WriteLine("Nem szerepel az adatállományban!");
            }



            //5. feladat adósáv összegzése
            int a_sav_db = 0;
            int a_sav_ado = 0;

            int b_sav_db = 0;
            int b_sav_ado = 0;

            int c_sav_db = 0;
            int c_sav_ado = 0;

            foreach (EpitmenyStruktura telek in adatok)
            {
                if (telek.adosav == 'A')
                {
                    a_sav_db++;
                    a_sav_ado = a_sav_ado + ado(telek.adosav, telek.terulet);
                }

                else if (telek.adosav == 'B') 
                {
                    b_sav_db++;
                    b_sav_ado = b_sav_ado + ado(telek.adosav, telek.terulet);
                }

                else
                {
                    c_sav_db++;
                    c_sav_ado = c_sav_ado + ado(telek.adosav, telek.terulet);
                }
            }
            Console.WriteLine("\n5. feladat)");
            Console.WriteLine($"A sávba {a_sav_db} telek esik, az adó {a_sav_ado} Ft.");
            Console.WriteLine($"A sávba {b_sav_db} telek esik, az adó {b_sav_ado} Ft.");
            Console.WriteLine($"A sávba {c_sav_db} telek esik, az adó {c_sav_ado} Ft.");


            //6. Feladat A több sávba sorolt utcák (halmazzal)

            Console.WriteLine("\n6. feladat) A több sávba sorolt utcák:");
            HashSet<string> utcanevekegyszer = new HashSet<string>();         //Halmaz létrehozása.
            HashSet<char> utcasavok = new HashSet<char>();

            foreach (EpitmenyStruktura telek in adatok)                     //Select distinct (minden utca név egyszer) 
            {
                utcanevekegyszer.Add(telek.utcaNev);
            }

            foreach (string utcanev in utcanevekegyszer)
            {
                foreach (EpitmenyStruktura telek in adatok)
                {
                    if (utcanev == telek.utcaNev)
                    {
                        utcasavok.Add(telek.adosav);
                    }
                }
                if (utcasavok.Count() > 1) 
                {
                    Console.Write(utcanev + "\n");
                }
                utcasavok.Clear();
            }


            //7. Feladat ! A tulajdonos adószámát és a fizetendő összeget írassa ki a mintának megfelelően a fizetendo.txt
        }
    }
}
