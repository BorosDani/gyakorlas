﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JanosVitez_II
{
    class Program
    {
        static void Main(string[] args)
        {
            janosvitez();
            Console.ReadLine();

            /*      
             *      a.      Kérj be egy betűt, és mondd meg, hányszor szerepel a dokumentumban. Figyelj arra, hogy vannak betűk, melyek egy szóban többször is előfordulhatnak.

                    b.      A bekért betűről mondd meg, hányadik szóban szerepel először, és írasd ki ezt a szót.

                    c.      Írasd ki a képernyőre a verset, úgy mintha hátulról olvasnánk visszafelé (csak a szavak sorrendjét változtasd meg).

                    d.      Írasd ki a verset ritkítva (minden betű között legyen egy szóköz).

                    e.      Írd a verset 2x fájlba úgy, hogy függőlegesen, fentről lefelé kelljen olvasni. Először minden sorba egyetlen szó kerüljön, utána pedig minden sorba egyetlen betű kerüljön. Elé legyen beírva: „szavanként:”, „betűnként:”. A fájl neve: JanosVitezFuggoleges.txt, helye a Forras mappa, mely egy szinten legyen a projektmappával.
            */
        }

        private static void janosvitez() 
        {
            string szoveg;
            string [] szavak;
            List<string> osszesSzo = new List<string>();
            StreamReader olvasocsatrona = new StreamReader("JanosVitez.txt", Encoding.GetEncoding("iso-8859-2"), false);
            while (!olvasocsatrona.EndOfStream) 
            {
                szoveg = olvasocsatrona.ReadLine();
                szavak = szoveg.Split(' ');
                for (int i = 0; i < szavak.Length; i++)
                {
                    osszesSzo.Add(szavak[i]); 
                }
            }
            olvasocsatrona.Close();

            Console.WriteLine("--- János Vitéz feladatok 2.rész ---\n\n");
            Console.Write("A szövegben melyik betűt szeretnéd megszámolni? ");

            string betu = Console.ReadLine();

            //a) változók
            string jelenlegiBetu;            
            int betuSzama = 0;
            //----------------

            //b) változók
            string elsoSz = "";
            bool elsoSzo = false;
            //----------------

            foreach (string szo in osszesSzo)
            {
                for (int i = 0; i < szo.Length; i++)
                {
                    jelenlegiBetu = szo[i].ToString();
                    if (jelenlegiBetu == betu) 
                    {
                        betuSzama++;
                        //b)
                        if (!elsoSzo)
                        {
                            elsoSz = szo;
                            elsoSzo = true;
                        }
                    }
                }
            }

            Console.WriteLine($"a) A(z) '{betu}' betű {betuSzama} alkalommal szerepel a szövegben.");
            Console.WriteLine($"\nb) Az első szó amiben ez a betű szerepel: {elsoSz}");

            for (int i = osszesSzo.Count(); i > 0; i++)
            {
                Console.WriteLine(osszesSzo[i]);
            }
        }
    }
}
