﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JanosVitez
{
    class Program
    {
        static void Main(string[] args)
        {
            janosvitez();
            Console.ReadLine();
        }

        private static void janosvitez()
        {
            int szo_szama = 0;
            int a_betu = 0;
            int nevelok_szama = 0;
            int nagy_betus_szavak = 0;
            int irasjelek_szama = 0;
            string tizedik_szo = "";
            string leghosszabb_szo = "";
            string szavak;
            string[] darabol;
            string szo;
            char karakter;
            char elsoBetu;
            bool szerepelt;
            List<string> szerepeltSzavak = new List<string>();
            List<char> szerepeltIrasjelek = new List<char>();

            //Beolvasás
            StreamReader olvasocsatorna = new StreamReader("JanosVitez.txt", Encoding.GetEncoding("iso-8859-2"), false);

            while (!olvasocsatorna.EndOfStream)
            {
                szavak = olvasocsatorna.ReadLine();
                darabol = szavak.Split(' ');
                leghosszabb_szo = darabol[0];
                //e)        A tizedik szó megoldása
                tizedik_szo = darabol[9];

                for (int i = 0; i < darabol.Length; i++)
                {
                    //a)        A szavak számának megoldása
                    szo_szama++;

                    //c)        Az "a" névelő számának megoldása
                    if (darabol[i].ToLower() == "a")
                    {
                        a_betu++;
                    }
                    //d)        Nevelők számának megoldása
                    if (darabol[i].ToLower() == "egy" || darabol[i].ToLower() == "a" || darabol[i].ToLower() == "az")
                    {
                        nevelok_szama++;
                    }
                    //f)        Nagy betűvel kezdődő szavak megoldása
                }

                //b)            A leghosszabb szó megoldása
                for (int i = 1; i < darabol.Length; i++)
                {
                    if (leghosszabb_szo.Length < darabol[i].Length)
                    {
                        leghosszabb_szo = darabol[i];
                    }
                }

                for (int i = 0; i < darabol.Length; i++)
                {
                    szo = darabol[i];

                    elsoBetu = szo[0];

                    if (elsoBetu >= 'A' && elsoBetu <= 'Z')
                    {
                        szerepelt = false;

                        for (int j = 0; j < szerepeltSzavak.Count; j++)
                        {
                            if (szerepeltSzavak[j] == szo)
                            {
                                szerepelt = true;
                            }
                        }

                        if (szerepelt == false)
                        {
                            nagy_betus_szavak++;
                            szerepeltSzavak.Add(szo);
                        }
                    }
                }

                for (int i = 0; i < szavak.Length; i++)
                {
                    karakter = szavak[i];
                    if (karakter == '.' || karakter == ',' || karakter == '!' || karakter == '?' || karakter == ';' || karakter == ':' || karakter == '-')
                    {
                        szerepelt = false;

                        for (int j = 0; j < szerepeltIrasjelek.Count; j++)
                        {
                            if (szerepeltIrasjelek[j] == karakter)
                            {
                                szerepelt = true;
                                irasjelek_szama++;
                            }
                        }

                        if (szerepelt == false)
                        {
                            irasjelek_szama++;
                            szerepeltIrasjelek.Add(karakter);
                        }
                    }
                }
            }

            olvasocsatorna.Close();

            //Eredmények kiírása
            Console.WriteLine("\t--- János Vitéz egyik részletéről feladatokra a válaszok ---\n\n");
            Console.WriteLine($"a)\tSzavak száma: {szo_szama}");
            Console.WriteLine($"\nb)\tLeghosszabb szó betűinek száma: {leghosszabb_szo.Length}\n\tLeghosszabb szó: {leghosszabb_szo}");
            Console.WriteLine($"\nc)\tAz a névelők száma: {a_betu}");
            Console.WriteLine($"\nd)\tNévelők száma: {nevelok_szama}");
            Console.WriteLine($"\ne)\tA tizedik szó: {tizedik_szo}");
            Console.WriteLine($"\nf)\tNagybetűs szavak száma: {nagy_betus_szavak}");
            Console.WriteLine($"\ng)\tÍrásjelek száma (vesszőkkel együtt): {irasjelek_szama}");
        }
    }
}
