<?php
    session_start();
    $_SESSION['logged'] = false;
?>


<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bejelentkezés</title>
</head>
<body>
    <form method="post">
        <div class="login_box">
            <input type="text" name="username" placeholder="Felhasználónév"><br>
            <input type="password" name="password" placeholder="Jelszó">
        </div>

        <input type="submit" class="confirm_button" name="login" value="Bejelentkezés">
        <p>Még nincs fiókod? akkor<a href="signup.php" class="login_way"> Regisztrálj</a></p>
    </form>
</body>
</html>


<?php
    
?>