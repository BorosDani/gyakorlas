<?php
    session_start();
    include_once("connection.php");
?>


<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció</title>
</head>
<body>
    <form method="post">
        <div class="signup_box">
            <input type="text" name="email" placeholder="Email"><br>
            <input type="text" name="username" placeholder="Felhasználónév"><br>
            <input type="password" name="password" placeholder="Jelszó"><br>
            <input type="password" name="re_password" placeholder="Jelszó újra"><br>
        </div>

        <input type="submit" class="confirm_button" name="signup" value="Regisztráció">
        <p>Van fiókod? akkor<a href="login.php" class="login_way"> Jelentkezz be</a></p>
    </form>
</body>
</html>


<?php
    if(empty($_POST['email']) || empty($_POST['username']) || empty($_POST['password']) || empty($_POST['re_password']))
    {
        exit("Kérlek töltsd ki az összes mezőt!");
    }

    elseif($_POST['re_password'] != $_POST['password'])
    {
        exit("A két jelszó nem egyezik!");
    }

    else
    {
        exit("Sikeres regisztráció!");
    }
?>