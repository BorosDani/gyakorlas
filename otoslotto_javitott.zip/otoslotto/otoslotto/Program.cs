﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace otoslotto
{
    class Program
    {
        static void Main(string[] args)
        {
            otoslottofeladatok();
            Console.ReadLine();
        }

        private static void lottoszamok()
        {
            Console.WriteLine("     52. hét lottószámai\n");
            for (int i = 1; i <= 90; i++)
            {
                Console.Write(i + " ");
                if (i % 10 == 0) 
                {
                    Console.WriteLine();
                }
                if (i < 10) 
                {
                    Console.Write(" ");
                }
            }
            Console.Write("\nAdd meg tippjeidet: ");
        }

        private static void otoslottofeladatok()
        {
            //1)
            List<string> tippek = new List<string>();
            for (int i = 0; i <= 4; i++)
            {
                lottoszamok();
                tippek.Add(Console.ReadLine());
                Console.Clear();
            }

            //2)
            Console.Write("Az általad megadott számok növekvő sorrendben: ");
            for (int i = 0; i < tippek.Count; i++)
            {
                tippek.Sort();
                Console.Write(tippek[i] + " ");
            }

            //3) [A nyeroszamokkal dolgozunk a kb 6 feladattól]
            string szamok;
            string[] darabol;
            List<string> nyeroszamok = new List<string>();
            List<string> Valasztottnyeroszamok = new List<string>();

            StreamReader olvasocsatorna = new StreamReader("lottoszamok.csv");
            while (!olvasocsatorna.EndOfStream) 
            {
                szamok = olvasocsatorna.ReadLine();
                Valasztottnyeroszamok.Add(szamok);

                darabol = szamok.Split();
                for (int i = 0; i < darabol.Length; i++)
                {
                    nyeroszamok.Add(darabol[i]);
                }
            }
            olvasocsatorna.Close();

            //4)
            Console.Write("\n\nÍrj be egy számot 1 és 51 között: ");
            int lottoHet = Convert.ToInt32(Console.ReadLine());

            //5)
            Console.Write("\n\nA választott heti nyerőszámok: ");
            for (int i = 0; i < Valasztottnyeroszamok.Count; i++)
            {
                if (lottoHet == i) 
                {
                    Console.WriteLine(Valasztottnyeroszamok[i-1]);
                }
            }

            //6)
            bool kihuztakE = false;

            //7)
            int paratlanSzamok = 0;
            for (int i = 0; i < nyeroszamok.Count; i++)
            {
                if (Convert.ToInt32(nyeroszamok[i]) % 2 != 0) 
                {
                    paratlanSzamok++;
                }
            }
            Console.WriteLine($"\n\nA lottóhetek páratlan számainak mennyisége: {paratlanSzamok}");

            //8)
            Console.WriteLine("Lotto 52 hét írása...");
            StreamWriter irocsatorna = new StreamWriter("lotto52.txt");

            for (int i = 0; i < Valasztottnyeroszamok.Count; i++)
            {
                irocsatorna.WriteLine(Valasztottnyeroszamok[i]);
            }
            for (int i = 0; i < tippek.Count; i++)
            {
                irocsatorna.Write(tippek[i] + " ");
            }
            
            irocsatorna.Close();
            Console.WriteLine("Lotto írása sikeres...(lotto52.txt)");

            //9)
            int DarabSzamlalo = 0;
            string DarabSzamlalohozEgyesevel = "1";
            string OtvenkettedikHetSzamai;
            string[] darabolOtvenKetto;
            List<string> otvenketto = new List<string>();
            StreamReader olvasocsatorna2 = new StreamReader("lotto52.txt");
            while (!olvasocsatorna2.EndOfStream) 
            {
                OtvenkettedikHetSzamai = olvasocsatorna2.ReadLine();
                darabolOtvenKetto = OtvenkettedikHetSzamai.Split(' ');
                for (int i = 0; i < darabolOtvenKetto.Length; i++)
                {
                    otvenketto.Add(darabolOtvenKetto[i]);
                }
            }
            olvasocsatorna2.Close();
        }
    }
}